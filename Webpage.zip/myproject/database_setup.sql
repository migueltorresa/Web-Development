
CREATE DATABASE IF NOT EXISTS LawFirmDB;

USE LawFirmDB;

-- Users table
CREATE TABLE IF NOT EXISTS Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'lawyer', 'client') NOT NULL,
    email VARCHAR(255) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cases table
CREATE TABLE IF NOT EXISTS Cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_name VARCHAR(255) NOT NULL,
    description TEXT,
    status ENUM('open', 'closed', 'pending') DEFAULT 'open',
    assigned_to INT,
    client_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES Users(id),
    FOREIGN KEY (client_id) REFERENCES Users(id)
);

-- Appointments table
CREATE TABLE IF NOT EXISTS Appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    case_id INT,
    appointment_date DATETIME NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(id),
    FOREIGN KEY (case_id) REFERENCES Cases(id)
);

-- Documents table
CREATE TABLE IF NOT EXISTS Documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES Cases(id)
);

-- Insert sample data
INSERT INTO Users (username, password, role, email) VALUES
('admin', MD5('admin123'), 'admin', 'admin@lawfirm.com'),
('lawyer1', MD5('lawyer123'), 'lawyer', 'lawyer1@lawfirm.com'),
('client1', MD5('client123'), 'client', 'client1@lawfirm.com');

INSERT INTO Cases (case_name, description, status, assigned_to, client_id) VALUES
('Case 1', 'Legal dispute over property', 'open', 2, 3),
('Case 2', 'Divorce proceedings', 'closed', 2, 3);

INSERT INTO Appointments (user_id, case_id, appointment_date, notes) VALUES
(3, 1, '2024-12-10 10:00:00', 'Initial consultation regarding property dispute'),
(3, 2, '2024-12-15 14:00:00', 'Final meeting for divorce case resolution');
