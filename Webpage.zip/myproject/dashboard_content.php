
<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo "Please log in to view this content.";
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM Cases WHERE client_id = ?) AS case_count,
        (SELECT COUNT(*) FROM Appointments WHERE user_id = ?) AS appointment_count
");
$stmt->execute([$userId, $userId]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<h2>Dashboard</h2>";
echo "<p>You have {$data['case_count']} cases and {$data['appointment_count']} appointments.</p>";
?>
