
<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo "Please log in to view this content.";
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM Appointments WHERE user_id = ?");
$stmt->execute([$userId]);

echo "<h2>Your Appointments</h2>";
if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<div><strong>Date:</strong> {$row['appointment_date']}<br>
              <strong>Notes:</strong> {$row['notes']}</div><hr>";
    }
} else {
    echo "<p>No appointments found.</p>";
}
?>
