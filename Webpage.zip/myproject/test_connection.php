
<?php
include 'config.php';

try {
    $pdo->query("SELECT 1");
    echo "Connection successful!";
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
