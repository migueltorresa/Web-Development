
<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo "Please log in to view this content.";
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM Cases WHERE client_id = ?");
$stmt->execute([$userId]);

echo "<h2>Your Cases</h2>";
if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<div><strong>{$row['case_name']}</strong>: {$row['status']}</div><hr>";
    }
} else {
    echo "<p>No cases found.</p>";
}
?>
